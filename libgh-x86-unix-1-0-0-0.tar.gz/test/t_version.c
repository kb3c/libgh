/* -*- Mode: C; tab-width: 2; indent-tabs-mode: t; c-basic-offset: 2 -*- */
/* t_version.c
 *
 *
 */

#include "ut/ut.h"

int main( int argc, char** argv ) {
	ut_showheader( "t_version" );

  gh_printf( "%s v%d.%d.%d.%.2d %.4d (%.4d)\n", ghVersionGetTitle(), ghVersionGetMajor(), ghVersionGetMinor(), ghVersionGetRelease(), ghVersionGetRevision(), ghVersionGetProfileBuild(), ghVersionGetBuild() );

  gh_printf( "  %s\n", ghVersionGetCopyright() );

	ut_showfooter();
 return 0;

}