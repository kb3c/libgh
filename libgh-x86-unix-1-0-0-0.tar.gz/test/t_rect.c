/* -*- Mode: C; tab-width: 2; indent-tabs-mode: t; c-basic-offset: 2 -*- */
/* t_rect.c
 *
 * Copyright(c) 2015, polarysekt
 */

#include "ut/ut.h"

int main( int argc, char** argv ) {

  ghRECT*	pTR1;

  ut_showheader( "t_rect" );

  /* Re-Arrange to avoid memory reuse */
  gh_printf( "Create a ghRECT\n" );
  pTR1 = ghRectCreate( 0, 0, 10, 10 );

  gh_printf( "Query Values:\n" );
  gh_printf( "RECT: (%d,%d)-(%d,%d) [%d x %d]\n", ghRectGetX(pTR1), ghRectGetY(pTR1), ghRectGetX2(pTR1), ghRectGetY2(pTR1), ghRectGetWidth(pTR1), ghRectGetHeight(pTR1) );

  gh_printf( "TODO: Set some new values.\n" );

  gh_printf( "Query Values:\n" );
  gh_printf( "RECT: (%d,%d)-(%d,%d) [%d x %d]\n", ghRectGetX(pTR1), ghRectGetY(pTR1), ghRectGetX2(pTR1), ghRectGetY2(pTR1), ghRectGetWidth(pTR1), ghRectGetHeight(pTR1) );

  /* Create and Immediately Destroy */
  gh_printf( "Destroy a CreateSimple\n" );
  ghRectDestroy( ghRectCreateSimple() );



  gh_printf( "Destroy a ghRECT\n" );
  ghRectDestroy( pTR1 );

  ut_showfooter();

  return 0;

}
