/* -*- Mode: C; tab-width: 2; indent-tabs-mode: t; c-basic-offset: 2 -*- */
/* t_string.c
 *
 * Copyright(c) 2015, polarysekt
 */

#include "ut/ut.h"

int main( int argc, char** argv ) {
  char strstatic[] = "test static 1";
  char *strdyn;
  char *strcrea;

 ut_showheader( "t_string" );

  gh_printf( "SRC = %s\n", strstatic );
  gh_printf( "init  DEST :: %x\n", strdyn );

  strdyn = gh_malloc( gh_strlen(strstatic)+ 1 );
  strcrea = ghCreate( gh_strlen(strstatic) + 1 );
  gh_printf( "alloc DEST :: %x\n", strdyn );

  gh_strcpy( strdyn, strstatic );
  gh_printf( "DEST = %s\n", strdyn );

  gh_free( strdyn );
  gh_printf( "final DEST :: %x\n", strdyn );

  ut_showfooter();
  return 0;
}
