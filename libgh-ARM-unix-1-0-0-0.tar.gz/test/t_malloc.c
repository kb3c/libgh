/* -*- Mode: C; tab-width: 2; indent-tabs-mode: t; c-basic-offset: 2 -*- */
/* t_malloc.c
 *
 * Copyright(c) 2015, polarysekt
 */

#include "gh.h"

int main( int argc, char** argv ) {

  void *myobj = gh_malloc( 10 );

  gh_free( myobj );

  return 0;

}
