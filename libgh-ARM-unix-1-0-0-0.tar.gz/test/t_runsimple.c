#include "ut/ut.h"

int main() {
  int ret;
  ut_showheader( "t_runsimple" );
  ret = ghRunSimple();

  ut_showfooter();
  return ret;
}