/* -*- Mode: C; tab-width: 2; indent-tabs-mode: t; c-basic-offset: 2 -*- */
/* t_monitor.c
 *
 * Copyright(c) 2015, polarysekt
 */

#include "gh.h"

int main( int argc, char** argv ) {

  ghMONITOR* pm;
  
  
  return 0;

}
