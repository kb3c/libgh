/* -*- Mode: C; tab-width: 2; indent-tabs-mode: t; c-basic-offset: 2 -*- */
/* t_runnable.c
 *
 * Copyright(c) 2015, polarysekt
 */

#include "gh.h"

int main( int argc, char** argv ) {
  
  gh_printf( "t_runnable\n" );
  gh_printf( "%s v%d.%d.%d.%2d\n  BUILD: %4d (%4d)\n", ghVersionGetTitle(), ghVersionGetMajor(), ghVersionGetMinor(), ghVersionGetRelease(), ghVersionGetRevision(), ghVersionGetProfileBuild(), ghVersionGetBuild() );
  
  ghInit( &argc, &argv );
  
  
  
 return ghRunSimple();; 
  
}