/* -*- Mode: C; tab-width: 2; indent-tabs-mode: t; c-basic-offset: 2 -*- */
/* gh.h
 * master include file
 *
 * Copyright(c) 2015, polarysekt
 * */

#include <stdarg.h>   /* ... , va_ */
#include <stddef.h>   /* size_t */

/* gh Debugging */
#  ifndef NDEBUG
#    define ghDBGprintf(...)		gh_printf( __VA_ARGS__ )
#  else
#    define ghDBGprintf(...)		((void)0)
#  endif

/* gh PLATFORMS */
#  define ghP_NONE	0
#  define ghP_MSWIN	100
#  define ghP_X		200
#  define ghP_MAC	300
#  define ghP_CURSES	900

/* gh STANDARD types */
typedef char	ghBOOL;
typedef int	ghRET;

/* TODO: */
typedef union {
  int	i;
} ghVARIANT;

/* TODO: error enum */

enum {
	ghERROR_ = -255,
	ghERROR_ARG_INVALID,
	ghERROR_RUNNABLE_INVALID,
	ghERROR_RECT_INVALID,
	ghERROR_WINDOW_INVALID,
	ghSUCCESS = 0
} ghERROR;

/* Forward Declarations */
typedef struct t_ghAPPLICATION	ghAPPLICATION;
typedef struct t_ghFONT		ghFONT;
typedef struct t_ghGENERIC	ghGENERIC;
typedef struct t_ghHANDLER	ghHANDLER;
typedef struct t_ghIMAGE	ghIMAGE;
typedef struct t_ghMONITOR	ghMONITOR;
typedef struct t_ghRECT		ghRECT;
typedef struct t_ghRUNNABLE 	ghRUNNABLE;
typedef struct t_ghTGAIMAGE	ghTGAIMAGE;
typedef struct t_ghWINDOW	ghWINDOW;

/* Standard C Wrappers */
void 	*gh_malloc( size_t size );
void 	gh_free( );

int 	gh_printf( const char *fmt, ... );
#define ghprintf gh_printf

char	*gh_strcpy( char* dest, const char* source );
int 	gh_strlen( const char* str );
int	gh_strchr( const char* str, char ch );

void *ghCreate( size_t size );
void *ghCreateSimple( );

ghRUNNABLE 		*ghInit( int *pargv, char ***pargc );
ghRUNNABLE 		*ghInitSimple( );

ghRECT			*ghRectCreate( int x, int y, unsigned int width, unsigned int height );
ghRECT			*ghRectCreateSimple();
void			ghRectDestroy( ghRECT* pr );

ghRET			ghRectSetRect( ghRECT* dest, const ghRECT* src );
int			ghRectGetX( ghRECT* pr );
int			ghRectGetY( ghRECT* pr );
int			ghRectGetX2( ghRECT* pr );
int			ghRectGetY2( ghRECT* pr );
int			ghRectGetWidth( ghRECT* pr );
int			ghRectGetHeight( ghRECT* pr );
ghRET			ghRectGetExtent2i( ghRECT* pr, int *width, int *height );
ghRET			ghRectGetPosition2i( ghRECT* pr, int *x, int *y );

ghRET			ghRectSetX( ghRECT* pr, int x );
ghRET			ghRectSetY( ghRECT* pr, int y );
ghRET			ghRectSetX2( ghRECT* pr, int x2 );
ghRET			ghRectSetY2( ghRECT* pr, int y2 );
ghRET			ghRectSetWidth( ghRECT* pr, int width );
ghRET			ghRectSetHeight( ghRECT* pr, int height );
ghRET			ghRectSetExtent2i( ghRECT* pr, int width, int height );
ghRET			ghRectSetPosition2i( ghRECT* pr, int x, int y );

int			ghRun( ghRUNNABLE* pr );
#define ghExec ghRun
int			ghRunSimple( );
#define ghExecSimple ghRunSimple

ghRUNNABLE *ghRunnableGetDefault( );
ghRET ghRunnableSetDefault( ghRUNNABLE *pr );

ghRUNNABLE		*ghRunnableInit( int *pargc, char ***pargv );
ghRUNNABLE		*ghRunnableCreate( ghRUNNABLE* pr);

int			ghRunnableExec( ghRUNNABLE *pRunr );
#define ghRunExec ghRunnableExec


void ghShutdown();


ghAPPLICATION	*ghApplicationCreate( );
int			ghApplicationExec( ghAPPLICATION *papp );
#define	ghAppExec ghApplicationExec
#define ghApplicationRun ghApplicationExec
#define ghAppRun ghApplicationExec


ghTGAIMAGE 		*ghTGALoadFromFile( const char* filespec );
ghRET			ghTGASaveToFile( ghTGAIMAGE* pimg, const char* filespec );

int			ghVersionGetMajor();
int			ghVersionGetMinor();
int			ghVersionGetRelease();
int			ghVersionGetRevision();
int			ghVersionGetProfileBuild();
int			ghVersionGetBuild();
char			*ghVersionGetAuthor();
char			*ghVersionGetTitle();
char			*ghVersionGetCopyright();
char			*ghVersionGetPlatform();

ghWINDOW*	ghWindowInit();
ghWINDOW*	ghWindowCreate( ghWINDOW* pw );

void		ghWindowShow( ghWINDOW* pw );
void		ghWindowHide( ghWINDOW* pw );

void		ghWindowSetShowState( ghWINDOW* pw, int ss );
int			ghWindowGetShowState( ghWINDOW* pw );